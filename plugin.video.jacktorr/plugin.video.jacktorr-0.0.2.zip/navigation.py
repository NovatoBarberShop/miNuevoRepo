from lib.navigation import run

run()
